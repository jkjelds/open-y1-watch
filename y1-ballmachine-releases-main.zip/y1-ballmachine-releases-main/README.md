# Y1 ball machine downloads

<p>
  <img src="docs/images/open-y1-trainer-icon.png" width="96" alt="Open Y1 Trainer app icon">
</p>

Installable Open Y1 Trainer APKs for the Nisplay Y1 tennis ball machine.

## v0.1.0-beta.3 (latest)

| App | Download | SHA-256 checksum |
| --- | --- | --- |
| Android phone (Android 7.0 or newer) | [Phone APK](https://github.com/axiophase/y1-ballmachine-releases/raw/refs/heads/main/downloads/v0.1.0-beta.3/open-y1-trainer-0.1.0-beta.3.apk) | [Checksum](downloads/v0.1.0-beta.3/open-y1-trainer-0.1.0-beta.3.apk.sha256) |
| Wear OS watch (Wear OS 3 or newer) | [Watch APK](https://github.com/axiophase/y1-ballmachine-releases/raw/refs/heads/main/downloads/v0.1.0-beta.3/open-y1-watch-0.1.0-beta.3.apk) | [Checksum](downloads/v0.1.0-beta.3/open-y1-watch-0.1.0-beta.3.apk.sha256) |

These are the signed v0.1.0-beta.3 APKs. Their signatures and checksums have been verified. This release enables R8 code and resource shrinking/obfuscation for both apps. Download and install the APK for your device.

## User guides and screenshots

- [Android phone user guide](docs/user-guides/android-app-user-guide.md): installation, drills, machine setup, controls, and alerts.
- [Wear OS user guide](docs/user-guides/wear-os-user-guide.md): installation, finding the watch app, connecting, drills, and presets.

### Android phone app

<p>
  <img src="docs/user-guides/images/android-drill-library.png" width="240" alt="Android drill library">
  <img src="docs/user-guides/images/android-drill-court.png" width="240" alt="Android drill court diagram">
  <img src="docs/user-guides/images/android-machine-ready.png" width="240" alt="Android machine controls and Quick start presets">
</p>

### Wear OS app

<p>
  <img src="docs/user-guides/images/wear-app-launcher.png" width="200" alt="Wear OS launcher with Open Y1 Watch">
  <img src="docs/user-guides/images/wear-drill-library.png" width="200" alt="Wear OS drill library">
  <img src="docs/user-guides/images/wear-drill-details.png" width="200" alt="Wear OS drill details">
</p>

Phone machine screenshots use the test simulator; watch screenshots use a Wear OS emulator.

APKs, checksums, user guides, and screenshots are stored directly in this repository. No application source code is included.

Application source repository (private; access required): https://github.com/axiophase/open-y1-trainer.
Latest application source tag: `v0.1.0-beta.3`; commit: `0533a10b57de684ad832502e54aef7dc4e378196`. Application licence: GPL-3.0-or-later.

<p>
  <a href="https://buymeacoffee.com/axiophase"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" width="160" alt="Buy Me A Coffee"></a>
</p>

This is an independent project, not made by or affiliated with Nisplay.
