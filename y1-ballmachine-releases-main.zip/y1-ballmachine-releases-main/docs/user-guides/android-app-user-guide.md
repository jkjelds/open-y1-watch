# Open Y1 Trainer Android user guide

Open Y1 Trainer has three main areas in the bottom navigation: **Drills**, **Machine**, and **About**. The Drills area contains the coaching library. Machine is a separate quick-control screen for a connected Y1.

## Install the phone app

1. Download the [phone APK](../../downloads/v0.1.0-beta.3/open-y1-trainer-0.1.0-beta.3.apk) on your Android phone (Android 7.0 or newer).
2. Open the downloaded APK. If prompted, allow your browser or file manager to install apps from this source, then tap **Install**.
3. Open **Open Y1 Trainer**. Installing the phone app does not install the separate watch app.

## Browse and choose a drill

1. Open **Open Y1 Trainer** and choose the **Drills** tab.
2. Browse the 40 bundled drills. Use the **All**, **Favorites**, or **My drills** filter, then use a category chip to narrow the list.
3. Tap a drill card to open its details. Review its goal, court diagram, machine/player positions, shot order, timing, repetitions, and tips.
4. Tap the heart in the top bar to add or remove the drill from Favorites.
5. Tap **Start session** to run the guided session view. The current Android session player is a simulator: it does not control a ball machine.

![Android Drills tab showing the filters and drill cards](images/android-drill-library.png)

![Android drill detail page with the goal, session summary, and simulator action](images/android-drill-details.png)

![Android court diagram showing the machine, player, and approximate shot targets](images/android-drill-court.png)

Technique-video buttons open a search in YouTube; video content is not hosted in the app.

## Create or manage drills

- Tap the **+** button in Drills to create a drill. Complete its title, goal, positions, shots, timing, and repetitions, then save. Validation issues appear in the editor.
- Bundled drills are read-only. Open one and use **More → Duplicate** to make an editable copy.
- On a drill detail page, **More** also offers sharing and export. User-created drills can be deleted.
- From the Drills overflow menu, choose **Import drills** to import JSON, or **Export all** to save the library as JSON. Imported drills are validated before they are stored.

## Connect and control a Y1

1. Open **Machine** in the bottom navigation.
2. Follow the setup steps: grant Bluetooth permissions, enable machine control after reading the safety confirmation, and find your machine.
3. Tap **Find machine**, then tap the matching Y1 in the results. Wait for its status to show ready.
4. Choose a Quick Start such as Deep middle, Forehand, Backhand, Alternate, Random, or Lobs. Set handedness and the Side A orientation so the side-target drills match your court.
5. Use **Fine tune** to adjust speed, spin, angle, and feed if needed. The displayed values are the machine’s supported Play settings.
6. Make sure the machine and court are clear, then tap **Start**. Tap **Stop** to stop firing.

Machine control is separate from **Start session** on a drill detail page. A coaching drill describes a tennis practice plan; the current app does not translate every authored drill into a verified Y1 firing program.

The **Court test** entry opens the machine field-test workflow. Use it only when you are intentionally checking machine output and can keep the court clear.

### Machine screens

These screenshots show the app connected to the test simulator, named **NESP-SIM**. Your own machine will show its Bluetooth name.

<img src="images/android-machine-setup.png" width="260" alt="Android Machine setup and Bluetooth permissions">
<img src="images/android-machine-ready.png" width="260" alt="Android Machine ready with Quick start presets">
<img src="images/android-machine-running.png" width="260" alt="Android Machine running with Stop control">

## Machine status, alerts, and logs

- The Machine screen shows connection/readiness and battery when reported by the machine.
- A machine fault or no-ball condition appears as an alert. Stop and resolve the machine issue before restarting.
- The Advanced section contains lower-level controls and diagnostics. Use the machine log export when collecting information for troubleshooting.
- If the machine disconnects while firing, treat the session as interrupted and check the machine before reconnecting.

<img src="images/android-machine-alert.png" width="260" alt="Android no-ball alert">

## Find the app again

Open **Open Y1 Trainer** from the Android launcher. Drills, Machine, and About are the tabs along the bottom of the app. On Android tablets or larger phones, the same tabs remain available in the bottom navigation.
