# Open Y1 Watch user guide

Open Y1 Watch is a separate Wear OS app for connecting to a Y1 machine and controlling supported machine presets from your wrist. The phone app remains the place to create and edit drills.

## Install the watch app

Download the [Wear OS APK](../../downloads/v0.1.0-beta.3/open-y1-watch-0.1.0-beta.3.apk). It requires Wear OS 3 or newer and must be installed on the watch itself, using an APK installer that supports Wear OS or ADB. Opening it on your phone does not install it on the watch.

## Find and open the watch app

1. Install **Open Y1 Watch** on the Wear OS watch. It is a separate app from Open Y1 Trainer, so installing the phone app does not by itself install the watch app.
2. On the watch, press the side button/crown to open the app launcher. Scroll the app list and tap **Open Y1 Watch** (look for the simple orange Y1 machine icon on a green background).
3. To make it quicker to find, long-press its launcher icon and add it to Favorites if your Wear OS version offers that option.

![Wear OS app launcher showing the Open Y1 Watch icon: an orange Y1 machine on green](images/wear-app-launcher.png)

The screenshots in this guide were captured on a Wear OS emulator. The same screens are available on a compatible physical watch.

## Connect to the machine

1. Open **Machine** from the watch home screen.
2. Allow Bluetooth access when prompted, and make sure Bluetooth is on.
3. Tap **Scan for Y1**. Choose the Y1 machine from the results to connect. The app remembers the machine for the next time it opens.
4. Open **Settings** and enable watch controls. Confirm that the court and machine are clear. This opt-in is required before Start can send a command.

The watch does not ask you to run court calibration. The machine still needs to be set up and safe to use before starting.

## Browse the 40 coaching drills

1. From Home, scroll to **Drill library · 40** and open it.
2. Scroll vertically or use the watch’s rotary input to browse. Each card uses a category icon and short drill title.
3. Tap a card for a compact summary. The machine icon and person icon show the two court positions; the ball icon is shot count/repetitions, and the clock icon is feed interval/recovery. Open the same drill in Open Y1 Trainer on your phone for its goal, complete shot order, and coaching tips.

![Wear OS drill library on the round-screen emulator, showing 40 drills](images/wear-drill-library.png)

![Wear OS compact drill summary with category icon, court positions, and short stats](images/wear-drill-details.png)

These cards are coaching guides. They do not program the machine: the authored phone drills describe tennis shots and court plans, while the watch’s verified machine controls use a separate set of presets.

## Choose and start a machine preset

1. From Home, open **Machine presets**.
2. Swipe left or right through the carousel. The card shows a court preview and the current position, such as `4 / 8`.
3. Tap a card to select it and return Home. The selected preset name appears above Start.
4. If needed, open **Adjust** to change speed, spin, angle, or feed for the selected preset.
5. Confirm the machine is connected and ready, watch controls are enabled, and the court is clear. Tap **Start**. Tap **Stop** to stop firing.

The eight supported presets are Deep middle, Two line wide, Lobs, Two line narrow, Random rally, Side A, Side B, and Fast middle. Direction names A/B are machine directions; their physical left/right orientation may depend on machine setup.

## Alerts and leaving the app

- A machine fault or out-of-balls condition stops the machine and opens an alert. If notifications are allowed, the watch also posts an alert to the Wear OS notification stream.
- Enable notifications when asked, or later from **Settings → Allow machine alerts**. The in-app alert still appears if notification permission is denied.
- The watch stops and disconnects from the machine when Open Y1 Watch leaves the foreground. Reconnect before starting again.
- Scanning only runs after you tap Scan and stops after its timeout or when you leave Machine.

## Battery and safe use

The app does not scan or poll while idle. It checks the machine less often while ready than while firing, and disconnects when the app backgrounds. Keep Stop easy to reach and supervise the machine whenever it is firing. Do not rely on the watch as an emergency stop if Bluetooth is disconnected.
